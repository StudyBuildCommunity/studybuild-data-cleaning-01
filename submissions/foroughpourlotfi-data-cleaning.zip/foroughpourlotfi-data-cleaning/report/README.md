# Customer Dataset Cleaning

## Overview

This project focuses on cleaning and validating a customer dataset using Python, Pandas, and NumPy.

## Data Cleaning Process

* Checked and handled missing values.
* Identified an invalid age value (`145`) and replaced it with the median after treating it as invalid.
* Filled the missing `total_spending` value using `purchase_count × avg_order_value`.
* Detected and removed one duplicated record.
* Reviewed data types and converted `signup_date` to `datetime` and `age` to integer.
* Checked categorical columns for inconsistent values and formatting.
* Checked the consistency between `city` and `province`.
* Detected outliers using the IQR method.
* Investigated outliers instead of removing them automatically.
* Corrected an inconsistent `total_spending` value (`25000` → `4079.14`).
* Rechecked the outliers after the correction and kept valid values.

## Final Dataset

The cleaned dataset was saved as:

`cleaned_dataset.xlsx`

## Tools

* Python
* Pandas
* NumPy
* Matplotlib
* Jupyter Notebook
