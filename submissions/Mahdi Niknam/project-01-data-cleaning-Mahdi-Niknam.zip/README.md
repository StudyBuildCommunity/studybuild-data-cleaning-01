# Customer Dataset — Cleaning & Exploratory Analysis

A Jupyter Notebook project that cleans a raw customer dataset and explores
purchasing behavior through visual analysis.

## About

This project takes a messy customer dataset (missing values, duplicates,
outliers, inconsistent types) and turns it into a clean, analysis-ready
table. It then explores the data to answer questions like: which cities
spend the most, which payment methods are most common, and whether
membership tier or discount usage affects total spending.

## Dataset

The raw data (`First Dataset.xlsx`) contains 17 columns per customer,
including:

| Column | Description |
|---|---|
| `customer_id` | Unique customer identifier |
| `first_name`, `gender`, `age`, `city`, `province` | Demographics |
| `signup_date`, `membership_tier` | Account info |
| `purchase_count`, `avg_order_value`, `total_spending` | Purchase behavior |
| `last_purchase_days`, `payment_method`, `device` | Shopping details |
| `discount_used`, `returned_items`, `satisfaction_score` | Engagement metrics |

## What I did

**Cleaning**
- Filled missing values in `age` and `total_spending` with the column mean
- Removed duplicate rows
- Fixed data types (`age` → int, `signup_date` → datetime)
- Removed outliers in `age` using the IQR method

**Exploratory analysis**
- Distributions and boxplots for all numeric columns (before/after cleaning)
- Correlation heatmap and pairwise scatter matrix
- Spending by city and by customer
- Most common payment methods
- Effect of discount usage on total spending
- Spending trends by signup month/day
- Membership tier vs. total spending

## Key findings

- Mashhad has the highest total
  spending among cities.
- online wallet is the most frequently used payment method.
- Higher membership tiers (VIP/Gold) correlate with higher total spending.
- *(add more insights from your notebook's output here)*

## Tech stack

- Python
- pandas
- matplotlib / seaborn

## How to run

```bash
pip install pandas matplotlib seaborn openpyxl
jupyter notebook data_cleaning.ipynb
```

Make sure `First Dataset.xlsx` is in the same folder as the notebook.

## Output

The cleaned dataset is saved as `cleaned_dataset.xlsx`.

## Project structure

```
.
├── data_cleaning.ipynb      # main notebook: cleaning + EDA
├── First Dataset.xlsx       # raw input data
├── cleaned_dataset.xlsx     # cleaned output
└── README.md
```
