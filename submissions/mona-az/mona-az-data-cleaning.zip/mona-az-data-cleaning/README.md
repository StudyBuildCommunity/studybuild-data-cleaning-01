# Project 01 — Data Cleaning on E-commerce Dataset

**Study&Build 2026**

---

## Project Introduction

This project focuses on cleaning an e-commerce customer dataset containing **61 rows and 17 columns**, including demographic information, purchasing behavior, payment-related information, and customer satisfaction data.

The goal of this project is to identify and handle data quality issues and prepare a cleaner and more reliable dataset for further analysis.

---

## Initial Data Inspection

The dataset was initially inspected using:

* Dataset shape and column names
* First and last rows
* Data types
* Summary statistics
* Missing values
* Duplicate records
* Duplicate `customer_id` values
* Invalid age values
* Invalid gender values
* Negative numeric values
* Statistical outliers using the IQR method
* Extra spaces in text columns
* City/province inconsistencies
* Logical consistency between `total_spending`, `avg_order_value`, and `purchase_count`
* Logical consistency between `returned_items` and `purchase_count`
* Name/gender inconsistencies

---

## Identified Data Issues

The following data quality issues were identified during the initial inspection:

| # | Issue                     | Description                                                                                                      |
| - | ------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| 1 | Missing Values            | Missing values were found in `age` and `total_spending`                                                          |
| 2 | Duplicate Records         | A completely duplicated record was identified                                                                    |
| 3 | Duplicate `customer_id`   | Duplicate customer IDs were identified                                                                           |
| 4 | Invalid Age               | One record contained an unrealistic age value of 145                                                             |
| 5 | Outliers                  | Statistical outliers were identified in `age` and `total_spending` using the IQR method                          |
| 6 | Name/Gender Inconsistency | Some records had a mismatch between clearly identifiable first names and the recorded gender                     |
| 7 | Logical Inconsistency     | One `total_spending` value was inconsistent with the relationship between `avg_order_value` and `purchase_count` |
| 8 | Invalid Returned Items    | Some records contained a `returned_items` value greater than `purchase_count`, which is logically impossible     |


### Additional Checks

The following potential issues were also checked:

* Negative values in numeric columns
* Extra spaces at the beginning or end of text values
* Multiple consecutive spaces
* City/province inconsistencies
* Invalid gender values
* Logical consistency of `total_spending`
* Logical consistency of `returned_items` and `purchase_count`

No issues were found in the following areas:

* Negative numeric values
* City/province consistency
* Extra spaces in text fields
* Invalid gender codes outside `M` and `F`

---

## Data Cleaning Process

### 1. Handling Invalid and Missing `age` Values

Invalid age values, defined as values below `0` or above `100`, were identified.

The invalid age value (`145`) was replaced with `NaN`. Missing and invalid age values were then replaced using the **median age** calculated from the valid records.

Finally, the `age` column was converted to the nullable integer type `Int64`.

---

### 2. Handling Missing `total_spending`

The missing value in `total_spending` was calculated using the following relationship:

```text
expected_spending = avg_order_value × purchase_count
```

This approach was chosen because the dataset contains a direct logical relationship between these variables, making it more appropriate than replacing the missing value with a statistical measure such as the mean.

---

### 3. Removing Duplicate Records

Completely duplicated rows were removed using:

```python
df_clean.drop_duplicates()
```

After that, duplicate `customer_id` values were handled by keeping only the first occurrence of each customer.

```python
df_clean.drop_duplicates(
    subset='customer_id',
    keep='first'
)
```

This ensured that each customer was represented by a single record in the final dataset.

---

### 4. Correcting Inconsistent `total_spending`

The consistency of `total_spending` was investigated by comparing it with:

```text
avg_order_value × purchase_count
```

Customer `1030` was identified as having an inconsistent `total_spending` value.

The recorded value was replaced with the logically expected value calculated as:

```text
purchase_count × avg_order_value
```

This correction ensured consistency between the customer's purchasing behavior and total spending.

---

### 5. Handling Statistical Outliers

The IQR method with a factor of `1.5` was used to identify statistical outliers in numeric variables.

For `total_spending`, the following bounds were calculated:

```text
Lower Bound = Q1 − 1.5 × IQR
Upper Bound = Q3 + 1.5 × IQR
```

The identified outliers were then investigated using the logical relationship:

```text
total_spending ≈ avg_order_value × purchase_count
```

Statistical outliers that were consistent with the customer's purchasing behavior were considered **valid observations** and were retained rather than automatically removed.

This approach recognizes that a statistical outlier is not necessarily a data error.

---

### 6. Correcting Name/Gender Inconsistencies

Potential inconsistencies between `first_name` and `gender` were identified using predefined lists of clearly identifiable male and female names.

The following names were used for the consistency check:

**Male names:**

* Reza
* Sina
* Parsa
* Ali
* Amir
* Arash
* Hossein
* Mohammad

**Female names:**

* Kimia
* Maryam
* Sara
* Zahra
* Negar
* Narges
* Yasaman
* Mina
* Neda

The `gender` values were manually standardized based on these clearly identifiable first names.

The final number of corrected inconsistencies is calculated programmatically in the final cleaning summary.

---

### 7. Cleaning Extra Spaces

Text columns were cleaned by:

* Removing leading spaces
* Removing trailing spaces
* Replacing multiple consecutive whitespace characters with a single space

This was applied to text-based columns in the cleaned dataset.

---

### 8. Data Type Handling

The `age` column was converted to the nullable integer type:

```text
Int64
```
### 9. Handling Invalid `returned_items`

The logical consistency of `returned_items` was checked against `purchase_count`.

Since the number of returned items cannot logically exceed the number of purchased items, records satisfying:

```text
returned_items > purchase_count
```

The `signup_date` column was kept in its original format in the final cleaned dataset.

The date column was initially inspected using `pd.to_datetime()` to verify that the values could be interpreted as valid dates, but the final cleaning process did not convert the column to a new date format.

---

## Final Data Quality Validation

After the cleaning process, the following checks were performed:

* Final dataset shape
* Remaining missing values
* Exact duplicate records
* Duplicate `customer_id` values
* Final data types

The final cleaning summary also reports:

* Number of removed exact duplicates
* Number of removed duplicate customer IDs
* Number of missing age values handled
* Number of invalid age values handled
* Number of missing `total_spending` values handled
* Number of inconsistent `total_spending` values corrected
* Number of name/gender inconsistencies corrected
* Number of valid statistical outliers retained

---

## Final Results

The final results are generated programmatically by the notebook to ensure that the reported values accurately reflect the actual cleaning process.

The main expected outcomes are:

| Metric                          | Result                                   |
| ------------------------------- | ---------------------------------------- |
| Initial number of rows          | 61                                       |
| Final number of rows            | 60                                       |
| Missing `age` values            | Handled                                  |
| Invalid `age` values            | Handled                                  |
| Missing `total_spending` values | Handled                                  |
| Exact duplicate records         | Removed                                  |
| Duplicate `customer_id` values  | Removed                                  |
| Inconsistent `total_spending`   | Corrected                                |
| Name/gender inconsistencies     | Corrected based on predefined name lists |
| Valid statistical outliers      | Retained                                 |

---

## Output

The cleaned dataset is exported as:

```text
cleaned_dataset.xlsx
```

The final output contains the cleaned customer records after applying the data quality and cleaning procedures described above.

---

## Libraries Used

* `pandas` — Data manipulation, cleaning, analysis, and Excel file handling
* `numpy` — Numerical calculations and statistical comparisons

---

## Conclusion

This project demonstrates a practical data cleaning workflow for an e-commerce customer dataset.

The cleaning process did not rely solely on statistical methods. Instead, statistical techniques such as the **IQR method** were combined with **business logic** and **data consistency checks**.

In particular, `total_spending` was validated against `avg_order_value` and `purchase_count`, allowing valid statistical outliers to be retained while correcting values that were logically inconsistent.

The resulting dataset is cleaner, more consistent, and better prepared for future exploratory data analysis, visualization, and machine learning tasks.
