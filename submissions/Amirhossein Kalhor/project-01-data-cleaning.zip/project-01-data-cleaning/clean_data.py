"""
اسکریپت اصلی پاکسازی داده‌های مشتری
Main data-cleaning script for customer dataset
"""

from __future__ import annotations

import sys
from datetime import date, datetime
from pathlib import Path
import shutil

import pandas as pd

# تنظیم encoding ترمینال ویندوز برای نمایش پیام‌های فارسی
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (OSError, ValueError):
        pass
from openpyxl import load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ─────────────────────────────────────────────────────────────────────────────
# مسیرها و ثابت‌های پروژه
# Project paths and constants
# ─────────────────────────────────────────────────────────────────────────────

PROJECT_DIR = Path(__file__).resolve().parent
INPUT_FILE = PROJECT_DIR / "First Dataset.xlsx"
OUTPUT_EXCEL = PROJECT_DIR / "cleaned_dataset.xlsx"
OUTPUT_CSV_REPORT = PROJECT_DIR / "data_cleaning_report.csv"

REQUIRED_COLUMNS = [
    "customer_id",
    "age",
    "gender",
    "signup_date",
    "purchase_count",
    "avg_order_value",
    "total_spending",
]

AGE_MIN = 0
AGE_MAX = 120
SPENDING_TOLERANCE = 0.01

# رنگ‌ها و استایل‌های اکسل
HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF")
PASS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
FAIL_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
WARN_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")

# لاگ ممیزی سراسری و آمار خلاصه
audit_records: list[dict] = []
summary_stats: dict[str, int | str] = {}


def _now_str() -> str:
    """برگرداندن زمان فعلی به‌صورت رشته ISO."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _log(
    customer_id,
    column_name: str,
    issue_type: str,
    original_value,
    cleaned_value,
    action_taken: str,
    reason: str,
    timestamp: str | None = None,
) -> None:
    """ثبت یک ردیف در گزارش ممیزی."""
    audit_records.append(
        {
            "timestamp": timestamp or _now_str(),
            "customer_id": customer_id if pd.notna(customer_id) else "",
            "column_name": column_name,
            "issue_type": issue_type,
            "original_value": original_value,
            "cleaned_value": cleaned_value,
            "action_taken": action_taken,
            "reason": reason,
        }
    )


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """
    نرمال‌سازی نام ستون‌ها:
    حروف کوچک، حذف فاصله‌های اضافی، جایگزینی فاصله داخلی با _
    """
    df = df.copy()
    new_columns = []
    for col in df.columns:
        normalized = str(col).strip().lower().replace(" ", "_")
        if normalized != col:
            _log(
                customer_id="",
                column_name=str(col),
                issue_type="whitespace_normalization",
                original_value=str(col),
                cleaned_value=normalized,
                action_taken="normalized_column_name",
                reason="Column name normalized to lowercase with underscores",
            )
        new_columns.append(normalized)
    df.columns = new_columns
    return df


def load_and_validate_data(input_path: Path) -> pd.DataFrame:
    """
    بارگذاری فایل اکسل و اعتبارسنجی وجود ستون‌های الزامی.
    در صورت نبود ستون، خطای خوانا صادر می‌شود.
    """
    if not input_path.exists():
        raise FileNotFoundError(
            f"فایل ورودی یافت نشد: {input_path}\nInput file not found: {input_path}"
        )

    try:
        df = pd.read_excel(input_path, engine="openpyxl")
    except Exception as exc:
        raise RuntimeError(
            f"خطا در خواندن فایل اکسل: {exc}\nFailed to read Excel file: {exc}"
        ) from exc

    df = normalize_column_names(df)
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError(
            "ستون‌های الزامی زیر در داده وجود ندارند:\n"
            f"Missing required columns: {', '.join(missing)}\n"
            f"Available columns: {', '.join(df.columns)}"
        )

    print(f"✓ داده با موفقیت بارگذاری شد: {len(df)} ردیف و {len(df.columns)} ستون")
    return df


def clean_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """
    مدیریت ردیف‌های تکراری و customer_id تکراری.
    - ردیف کاملاً یکسان: نگه‌داشتن اولین مورد
    - customer_id تکراری با داده متفاوت: نگه‌داشتن اولین مورد + ثبت تعارض
    """
    df = df.copy()
    removed_full_dupes = 0
    customer_id_conflicts = 0

    # ── ردیف‌های کاملاً یکسان ──
    duplicate_mask = df.duplicated(keep="first")
    for idx in df.index[duplicate_mask]:
        row = df.loc[idx]
        _log(
            customer_id=row.get("customer_id", ""),
            column_name="*",
            issue_type="fully_duplicate_row",
            original_value=str(row.to_dict()),
            cleaned_value="",
            action_taken="removed_duplicate_row",
            reason="Fully identical duplicate row removed; first occurrence kept",
        )
        removed_full_dupes += 1

    df = df.drop_duplicates(keep="first").reset_index(drop=True)

    # ── customer_id تکراری با محتوای متفاوت ──
    dup_ids = df["customer_id"][df["customer_id"].duplicated(keep=False)].unique()
    for cid in dup_ids:
        dup_rows = df[df["customer_id"] == cid]
        if len(dup_rows) <= 1:
            continue

        # اگر همه ردیف‌ها یکسان باشند، قبلاً حذف شده‌اند
        if dup_rows.drop_duplicates().shape[0] == 1:
            continue

        customer_id_conflicts += 1
        primary = dup_rows.iloc[0]
        for idx in dup_rows.index[1:]:
            conflict_row = df.loc[idx]
            _log(
                customer_id=cid,
                column_name="customer_id",
                issue_type="duplicate_customer_id",
                original_value=str(conflict_row.to_dict()),
                cleaned_value=str(primary.to_dict()),
                action_taken="kept_first_record",
                reason=(
                    f"Duplicate customer_id conflict; primary record kept. "
                    f"Review conflicting row at index {idx}."
                ),
            )
            df = df.drop(index=idx)

        df = df.reset_index(drop=True)

    summary_stats["removed_duplicate_rows"] = removed_full_dupes
    summary_stats["duplicate_customer_id_conflicts"] = customer_id_conflicts
    print(f"✓ پاکسازی تکراری‌ها: {removed_full_dupes} ردیف حذف شد")
    return df


def clean_age(df: pd.DataFrame) -> pd.DataFrame:
    """
    پاکسازی ستون age:
    - تبدیل امن به عددی
    - مقادیر خارج از بازه 0-120 نامعتبر
    - پر کردن مقادیر گم‌شده/نامعتبر با میانه
    """
    df = df.copy()
    age_numeric = pd.to_numeric(df["age"], errors="coerce")
    invalid_mask = age_numeric.isna() | (age_numeric < AGE_MIN) | (age_numeric > AGE_MAX)
    valid_ages = age_numeric[~invalid_mask]

    if valid_ages.empty:
        raise ValueError("هیچ مقدار age معتبری برای محاسبه میانه وجود ندارد.")

    median_age = int(round(valid_ages.median()))
    missing_filled = 0
    invalid_corrected = 0

    for idx in df.index:
        original = df.at[idx, "age"]
        numeric_val = pd.to_numeric(original, errors="coerce")
        cid = df.at[idx, "customer_id"]

        if pd.isna(numeric_val):
            if pd.isna(original) or str(original).strip() == "":
                _log(
                    customer_id=cid,
                    column_name="age",
                    issue_type="missing_value",
                    original_value=original,
                    cleaned_value=median_age,
                    action_taken="filled_with_median",
                    reason=f"Missing age filled with median ({median_age})",
                )
                missing_filled += 1
            else:
                _log(
                    customer_id=cid,
                    column_name="age",
                    issue_type="invalid_age",
                    original_value=original,
                    cleaned_value=median_age,
                    action_taken="replaced_with_median",
                    reason="Non-numeric age converted to missing then filled with median",
                )
                invalid_corrected += 1
            df.at[idx, "age"] = median_age
        elif numeric_val < AGE_MIN or numeric_val > AGE_MAX:
            _log(
                customer_id=cid,
                column_name="age",
                issue_type="invalid_age",
                original_value=original,
                cleaned_value=median_age,
                action_taken="replaced_with_median",
                reason=f"Age outside valid range ({AGE_MIN}-{AGE_MAX})",
            )
            invalid_corrected += 1
            df.at[idx, "age"] = median_age
        else:
            df.at[idx, "age"] = int(numeric_val)

    summary_stats["missing_ages_filled"] = missing_filled
    summary_stats["invalid_ages_corrected"] = invalid_corrected
    print(f"✓ پاکسازی age: {missing_filled} مقدار گم‌شده، {invalid_corrected} نامعتبر اصلاح شد")
    return df


def clean_signup_date(df: pd.DataFrame, execution_date: pd.Timestamp) -> pd.DataFrame:
    """
    پاکسازی signup_date:
    - تبدیل به datetime
    - تاریخ‌های آینده یا نامعتبر → NaT
    """
    df = df.copy()
    dates_corrected = 0

    original_dates = df["signup_date"].copy()
    parsed = pd.to_datetime(df["signup_date"], errors="coerce")

    for idx in df.index:
        original = original_dates.at[idx]
        cid = df.at[idx, "customer_id"]
        parsed_val = parsed.at[idx]

        if pd.isna(parsed_val):
            if pd.notna(original) and str(original).strip() != "":
                _log(
                    customer_id=cid,
                    column_name="signup_date",
                    issue_type="invalid_date",
                    original_value=original,
                    cleaned_value="",
                    action_taken="blanked_invalid_date",
                    reason="Unparseable signup_date replaced with blank",
                )
                dates_corrected += 1
        elif parsed_val.normalize() > execution_date.normalize():
            _log(
                customer_id=cid,
                column_name="signup_date",
                issue_type="future_date",
                original_value=original,
                cleaned_value="",
                action_taken="blanked_future_date",
                reason=f"Future date (after {execution_date.date()}) replaced with blank",
            )
            dates_corrected += 1
            parsed.at[idx] = pd.NaT

    # تبدیل کل ستون به datetime برای جلوگیری از خطای dtype
    df["signup_date"] = parsed

    summary_stats["invalid_future_dates_blanked"] = dates_corrected
    print(f"✓ پاکسازی signup_date: {dates_corrected} تاریخ نامعتبر/آینده خالی شد")
    return df


def clean_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    اعتبارسنجی purchase_count و avg_order_value:
    - تبدیل امن به عددی
    - مقادیر منفی → NaN
    """
    df = df.copy()

    for col in ("purchase_count", "avg_order_value"):
        numeric = pd.to_numeric(df[col], errors="coerce")
        for idx in df.index:
            original = df.at[idx, col]
            val = numeric.at[idx]
            cid = df.at[idx, "customer_id"]

            if pd.isna(val):
                if pd.notna(original) and str(original).strip() != "":
                    _log(
                        customer_id=cid,
                        column_name=col,
                        issue_type="invalid_numeric_value",
                        original_value=original,
                        cleaned_value="",
                        action_taken="set_to_missing",
                        reason=f"Invalid non-numeric value in {col}",
                    )
                df.at[idx, col] = pd.NA
            elif val < 0:
                _log(
                    customer_id=cid,
                    column_name=col,
                    issue_type="invalid_numeric_value",
                    original_value=original,
                    cleaned_value="",
                    action_taken="set_to_missing",
                    reason=f"Negative value in {col} is invalid",
                )
                df.at[idx, col] = pd.NA
            else:
                if col == "purchase_count":
                    df.at[idx, col] = int(val)
                else:
                    df.at[idx, col] = float(val)

    print("✓ اعتبارسنجی purchase_count و avg_order_value انجام شد")
    return df


def clean_total_spending(df: pd.DataFrame) -> pd.DataFrame:
    """
    پاکسازی total_spending:
    - پر کردن مقادیر گم‌شده از purchase_count × avg_order_value
    - اصلاح ناسازگاری‌های ریاضی با tolerance=0.01
    """
    df = df.copy()
    missing_filled = 0
    inconsistent_corrected = 0

    spending = pd.to_numeric(df["total_spending"], errors="coerce")

    for idx in df.index:
        original = df.at[idx, "total_spending"]
        cid = df.at[idx, "customer_id"]
        pc = pd.to_numeric(df.at[idx, "purchase_count"], errors="coerce")
        aov = pd.to_numeric(df.at[idx, "avg_order_value"], errors="coerce")
        current = spending.at[idx]

        can_calculate = pd.notna(pc) and pd.notna(aov)
        expected = round(float(pc * aov), 2) if can_calculate else None

        if pd.isna(current):
            if pd.notna(original) and str(original).strip() != "":
                _log(
                    customer_id=cid,
                    column_name="total_spending",
                    issue_type="invalid_numeric_value",
                    original_value=original,
                    cleaned_value=expected if can_calculate else "",
                    action_taken="set_to_missing_or_calculated",
                    reason="Invalid non-numeric total_spending",
                )
            if can_calculate:
                _log(
                    customer_id=cid,
                    column_name="total_spending",
                    issue_type="missing_total_spending",
                    original_value=original,
                    cleaned_value=expected,
                    action_taken="filled_with_calculated_value",
                    reason="Missing total_spending filled with purchase_count × avg_order_value",
                )
                df.at[idx, "total_spending"] = expected
                missing_filled += 1
            else:
                df.at[idx, "total_spending"] = pd.NA
        elif current < 0:
            _log(
                customer_id=cid,
                column_name="total_spending",
                issue_type="invalid_numeric_value",
                original_value=original,
                cleaned_value=expected if can_calculate else "",
                action_taken="corrected_negative_value",
                reason="Negative total_spending is invalid",
            )
            if can_calculate:
                df.at[idx, "total_spending"] = expected
                inconsistent_corrected += 1
            else:
                df.at[idx, "total_spending"] = pd.NA
        elif can_calculate:
            difference = abs(float(current) - expected)
            if difference > SPENDING_TOLERANCE:
                _log(
                    customer_id=cid,
                    column_name="total_spending",
                    issue_type="inconsistent_total_spending",
                    original_value=original,
                    cleaned_value=expected,
                    action_taken="replaced_with_calculated_value",
                    reason=(
                        f"Expected total = purchase_count × avg_order_value; "
                        f"{int(pc)} × {aov} = {expected}; "
                        f"difference = {difference:.2f}, which is greater than {SPENDING_TOLERANCE}"
                    ),
                )
                df.at[idx, "total_spending"] = expected
                inconsistent_corrected += 1
            else:
                df.at[idx, "total_spending"] = round(float(current), 2)
        else:
            df.at[idx, "total_spending"] = round(float(current), 2)

    summary_stats["missing_total_spending_filled"] = missing_filled
    summary_stats["inconsistent_total_spending_corrected"] = inconsistent_corrected
    print(
        f"✓ پاکسازی total_spending: {missing_filled} پر شد، "
        f"{inconsistent_corrected} ناسازگاری اصلاح شد"
    )
    return df


def clean_text_columns(df: pd.DataFrame) -> pd.DataFrame:
    """نرمال‌سازی فاصله‌ها در ستون‌های متنی مانند gender."""
    df = df.copy()
    text_cols = df.select_dtypes(include=["object", "string"]).columns

    for col in text_cols:
        for idx in df.index:
            original = df.at[idx, col]
            if pd.isna(original):
                continue
            cleaned = " ".join(str(original).split())
            if cleaned != str(original):
                _log(
                    customer_id=df.at[idx, "customer_id"],
                    column_name=col,
                    issue_type="whitespace_normalization",
                    original_value=original,
                    cleaned_value=cleaned,
                    action_taken="normalized_whitespace",
                    reason="Leading/trailing/repeated whitespace normalized",
                )
                df.at[idx, col] = cleaned

    print("✓ نرمال‌سازی ستون‌های متنی انجام شد")
    return df


def create_audit_log() -> pd.DataFrame:
    """ساخت DataFrame گزارش ممیزی از رکوردهای ثبت‌شده."""
    if not audit_records:
        return pd.DataFrame(
            columns=[
                "timestamp",
                "customer_id",
                "column_name",
                "issue_type",
                "original_value",
                "cleaned_value",
                "action_taken",
                "reason",
            ]
        )
    return pd.DataFrame(audit_records)


def create_type_formatting_changes() -> pd.DataFrame:
    """
    مستندسازی تبدیل‌های نوع داده و قالب‌بندی Excel (سطح dataset).
    این رکوردها جدا از Audit Log سطح ردیف هستند.
    """
    return pd.DataFrame(
        [
            {
                "column_name": "age",
                "change_category": "data_type_conversion",
                "transformation_applied": "Yes",
                "source_type": "mixed/numeric-converted",
                "final_type": "integer",
                "excel_number_format": "",
                "description": (
                    "Safely converted to numeric values. Missing and invalid values "
                    "were handled separately. Final valid values were stored as integers."
                ),
            },
            {
                "column_name": "signup_date",
                "change_category": "data_type_conversion",
                "transformation_applied": "Yes",
                "source_type": "text/string",
                "final_type": "datetime/date",
                "excel_number_format": "YYYY-MM-DD",
                "description": (
                    "Converted from text/string to datetime during processing. "
                    "Written to Excel as a date using YYYY-MM-DD format."
                ),
            },
            {
                "column_name": "purchase_count",
                "change_category": "data_type_conversion",
                "transformation_applied": "Yes",
                "source_type": "numeric/text-compatible",
                "final_type": "integer",
                "excel_number_format": "",
                "description": "Safely converted to integer values.",
            },
            {
                "column_name": "avg_order_value",
                "change_category": "data_type_conversion",
                "transformation_applied": "Yes",
                "source_type": "numeric/text-compatible",
                "final_type": "decimal/float",
                "excel_number_format": "#,##0.00",
                "description": (
                    "Safely converted to decimal values and displayed with 2 decimal places."
                ),
            },
            {
                "column_name": "total_spending",
                "change_category": "data_type_conversion",
                "transformation_applied": "Yes",
                "source_type": "numeric/text-compatible",
                "final_type": "decimal/float",
                "excel_number_format": "#,##0.00",
                "description": (
                    "Safely converted to decimal values and rounded to 2 decimal places."
                ),
            },
            {
                "column_name": "other columns",
                "change_category": "data_type_conversion",
                "transformation_applied": "No",
                "source_type": "unchanged",
                "final_type": "unchanged",
                "excel_number_format": "",
                "description": "No intentional data-type conversion was applied.",
            },
            {
                "column_name": "signup_date",
                "change_category": "excel_formatting",
                "transformation_applied": "Yes",
                "source_type": "datetime/date",
                "final_type": "datetime/date",
                "excel_number_format": "YYYY-MM-DD",
                "description": "Dates are displayed in a standardized YYYY-MM-DD format.",
            },
            {
                "column_name": "avg_order_value and total_spending",
                "change_category": "excel_formatting",
                "transformation_applied": "Yes",
                "source_type": "decimal/float",
                "final_type": "decimal/float",
                "excel_number_format": "#,##0.00",
                "description": (
                    "Monetary values are displayed with thousand separators "
                    "and exactly 2 decimal places."
                ),
            },
        ]
    )


def export_audit_csv(
    audit_df: pd.DataFrame, type_fmt_df: pd.DataFrame, output_path: Path
) -> None:
    """ذخیره Audit Log سطح ردیف + بخش جداگانه DATA TYPE AND EXCEL FORMATTING CHANGES."""
    with open(output_path, "w", encoding="utf-8-sig", newline="") as handle:
        audit_df.to_csv(handle, index=False)
        handle.write("\n")
        type_fmt_df.to_csv(handle, index=False)


def create_quality_checks(df: pd.DataFrame, execution_date: pd.Timestamp) -> pd.DataFrame:
    """
    ساخت جدول کنترل کیفیت پس از پاکسازی.
    هر بررسی باید PASS یا FAIL داشته باشد.
    """
    checks = []

    # ── مقادیر گم‌شده به تفکیک ستون ──
    for col in df.columns:
        missing_count = int(df[col].isna().sum())
        checks.append(
            {
                "check_category": "Missing Values",
                "check_name": f"Missing values in '{col}'",
                "expected": "0 missing (or acceptable for optional fields)",
                "actual": str(missing_count),
                "status": "PASS" if missing_count == 0 else "WARN",
            }
        )

    # ── customer_id تکراری ──
    dup_count = int(df["customer_id"].duplicated().sum())
    checks.append(
        {
            "check_category": "Uniqueness",
            "check_name": "Duplicate customer_id values",
            "expected": "0",
            "actual": str(dup_count),
            "status": "PASS" if dup_count == 0 else "FAIL",
        }
    )

    # ── age نامعتبر ──
    ages = pd.to_numeric(df["age"], errors="coerce")
    invalid_age = int(((ages < AGE_MIN) | (ages > AGE_MAX) | ages.isna()).sum())
    checks.append(
        {
            "check_category": "Age Validation",
            "check_name": f"Invalid age values (outside {AGE_MIN}-{AGE_MAX})",
            "expected": "0",
            "actual": str(invalid_age),
            "status": "PASS" if invalid_age == 0 else "FAIL",
        }
    )

    # ── تاریخ‌های آینده ──
    dates = pd.to_datetime(df["signup_date"], errors="coerce")
    future_count = int((dates.dropna() > execution_date.normalize()).sum())
    checks.append(
        {
            "check_category": "Date Validation",
            "check_name": "Future signup_date values",
            "expected": "0",
            "actual": str(future_count),
            "status": "PASS" if future_count == 0 else "FAIL",
        }
    )

    # ── ناسازگاری total_spending ──
    inconsistent = 0
    for _, row in df.iterrows():
        pc = pd.to_numeric(row["purchase_count"], errors="coerce")
        aov = pd.to_numeric(row["avg_order_value"], errors="coerce")
        ts = pd.to_numeric(row["total_spending"], errors="coerce")
        if pd.notna(pc) and pd.notna(aov) and pd.notna(ts):
            expected = round(float(pc * aov), 2)
            if abs(float(ts) - expected) > SPENDING_TOLERANCE:
                inconsistent += 1

    checks.append(
        {
            "check_category": "Spending Consistency",
            "check_name": "total_spending vs purchase_count × avg_order_value",
            "expected": f"All within tolerance ({SPENDING_TOLERANCE})",
            "actual": str(inconsistent),
            "status": "PASS" if inconsistent == 0 else "FAIL",
        }
    )

    # ── ردیف کاملاً تکراری ──
    full_dupes = int(df.duplicated().sum())
    checks.append(
        {
            "check_category": "Uniqueness",
            "check_name": "Fully duplicated rows",
            "expected": "0",
            "actual": str(full_dupes),
            "status": "PASS" if full_dupes == 0 else "FAIL",
        }
    )

    return pd.DataFrame(checks)


def _autosize_columns(ws, min_width: int = 10, max_width: int = 50) -> None:
    """تنظیم خودکار عرض ستون‌ها."""
    for col_idx, column_cells in enumerate(ws.iter_cols(min_row=1, max_row=ws.max_row), start=1):
        max_length = 0
        column_letter = get_column_letter(col_idx)
        for cell in column_cells:
            if cell.value is not None:
                max_length = max(max_length, len(str(cell.value)))
        adjusted = min(max(max_length + 2, min_width), max_width)
        ws.column_dimensions[column_letter].width = adjusted


def _apply_header_style(ws, row: int = 1) -> None:
    """اعمال استایل هدر: پر کردن آبی تیره و متن سفید."""
    for cell in ws[row]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _apply_status_formatting(ws, status_col: int, start_row: int = 2) -> None:
    """رنگ‌بندی شرطی برای ستون وضعیت PASS/FAIL/WARN."""
    col_letter = get_column_letter(status_col)
    cell_range = f"{col_letter}{start_row}:{col_letter}{ws.max_row}"
    ws.conditional_formatting.add(
        cell_range,
        CellIsRule(operator="equal", formula=['"PASS"'], fill=PASS_FILL),
    )
    ws.conditional_formatting.add(
        cell_range,
        CellIsRule(operator="equal", formula=['"FAIL"'], fill=FAIL_FILL),
    )
    ws.conditional_formatting.add(
        cell_range,
        CellIsRule(operator="equal", formula=['"WARN"'], fill=WARN_FILL),
    )


def _apply_table_borders(ws, min_row: int, max_row: int, min_col: int, max_col: int) -> None:
    """اعمال حاشیه یکسان برای جدول گزارش."""
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for row in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            cell.border = border


def export_formatted_excel(
    cleaned_df: pd.DataFrame,
    audit_df: pd.DataFrame,
    summary_df: pd.DataFrame,
    quality_df: pd.DataFrame,
    type_fmt_df: pd.DataFrame,
    output_path: Path,
) -> None:
    """
    خروجی اکسل حرفه‌ای با سه شیت:
    Cleaned_Data، Cleaning_Report، Data_Quality_Checks
    """
    # ── آماده‌سازی داده پاکسازی‌شده برای خروجی ──
    export_df = cleaned_df.copy()
    if "signup_date" in export_df.columns:
        export_df["signup_date"] = pd.to_datetime(export_df["signup_date"], errors="coerce")
    if "age" in export_df.columns:
        export_df["age"] = pd.to_numeric(export_df["age"], errors="coerce").astype("Int64")
    if "purchase_count" in export_df.columns:
        export_df["purchase_count"] = pd.to_numeric(
            export_df["purchase_count"], errors="coerce"
        ).astype("Int64")

    # ── نوشتن اولیه با pandas (ابتدا در فایل موقت برای جلوگیری از قفل بودن فایل) ──
    temp_output = output_path.with_name(f"{output_path.stem}_temp{output_path.suffix}")
    with pd.ExcelWriter(temp_output, engine="openpyxl") as writer:
        export_df.to_excel(writer, sheet_name="Cleaned_Data", index=False)

        # شیت گزارش: خلاصه + جزئیات Audit Log
        summary_df.to_excel(writer, sheet_name="Cleaning_Report", index=False, startrow=0)
        detail_start = len(summary_df) + 3
        audit_df.to_excel(
            writer,
            sheet_name="Cleaning_Report",
            index=False,
            startrow=detail_start,
        )

        # بخش DATA TYPE AND EXCEL FORMATTING CHANGES
        type_section_start = detail_start + len(audit_df) + 3
        type_fmt_df.to_excel(
            writer,
            sheet_name="Cleaning_Report",
            index=False,
            startrow=type_section_start,
        )

        quality_df.to_excel(writer, sheet_name="Data_Quality_Checks", index=False)

    # ── قالب‌بندی با openpyxl ──
    wb = load_workbook(temp_output)

    # ── شیت Cleaned_Data ──
    ws_data = wb["Cleaned_Data"]
    _apply_header_style(ws_data)
    ws_data.freeze_panes = "A2"
    ws_data.auto_filter.ref = ws_data.dimensions
    _autosize_columns(ws_data)

    # فرمت تاریخ، عدد صحیح و پولی
    header_map = {cell.value: cell.column for cell in ws_data[1]}
    date_fmt = "YYYY-MM-DD"
    money_fmt = "#,##0.00"
    integer_fmt = "0"
    if "signup_date" in header_map:
        col = header_map["signup_date"]
        for row in range(2, ws_data.max_row + 1):
            ws_data.cell(row=row, column=col).number_format = date_fmt
    for int_col in ("age", "purchase_count"):
        if int_col in header_map:
            col = header_map[int_col]
            for row in range(2, ws_data.max_row + 1):
                ws_data.cell(row=row, column=col).number_format = integer_fmt
    for money_col in ("avg_order_value", "total_spending"):
        if money_col in header_map:
            col = header_map[money_col]
            for row in range(2, ws_data.max_row + 1):
                ws_data.cell(row=row, column=col).number_format = money_fmt

    # ── شیت Cleaning_Report ──
    ws_report = wb["Cleaning_Report"]
    _apply_header_style(ws_report, row=1)
    detail_header_row = len(summary_df) + 3
    _apply_header_style(ws_report, row=detail_header_row)
    ws_report.cell(row=detail_header_row - 1, column=1, value="Detailed Audit Log").font = Font(
        bold=True, size=12
    )

    type_section_title_row = detail_start + len(audit_df) + 3
    type_section_header_row = detail_start + len(audit_df) + 4
    _apply_header_style(ws_report, row=type_section_header_row)
    ws_report.cell(
        row=type_section_title_row,
        column=1,
        value="DATA TYPE AND EXCEL FORMATTING CHANGES",
    ).font = Font(bold=True, size=12)
    _apply_table_borders(
        ws_report,
        min_row=type_section_header_row,
        max_row=type_section_header_row + len(type_fmt_df),
        min_col=1,
        max_col=len(type_fmt_df.columns),
    )
    ws_report.freeze_panes = "A2"
    for row in ws_report.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    _autosize_columns(ws_report)

    # ── شیت Data_Quality_Checks ──
    ws_qc = wb["Data_Quality_Checks"]
    _apply_header_style(ws_qc)
    ws_qc.freeze_panes = "A2"
    ws_qc.auto_filter.ref = ws_qc.dimensions
    status_col = list(quality_df.columns).index("status") + 1
    _apply_status_formatting(ws_qc, status_col)
    for row in ws_qc.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    _autosize_columns(ws_qc)

    wb.save(temp_output)

    # جایگزینی فایل نهایی
    try:
        if output_path.exists():
            output_path.unlink()
        shutil.move(str(temp_output), str(output_path))
        print(f"✓ فایل اکسل نهایی ذخیره شد: {output_path}")
    except PermissionError:
        fallback = output_path.with_name(f"{output_path.stem}_new{output_path.suffix}")
        if fallback.exists():
            fallback.unlink()
        shutil.move(str(temp_output), str(fallback))
        print(
            f"⚠ فایل {output_path.name} قفل است (احتمالاً در Excel باز است). "
            f"خروجی در {fallback.name} ذخیره شد. فایل Excel را ببندید و دوباره اجرا کنید."
        )


def validate_output(df: pd.DataFrame, audit_df: pd.DataFrame) -> dict[str, bool]:
    """
    اعتبارسنجی خروجی پس از نوشتن فایل اکسل.
    فقط داده‌های واقعاً اصلاح‌شده باید در گزارش ممیزی باشند.
    """
    results: dict[str, bool] = {}

    results["output_rows_60"] = len(df) == 60
    results["no_fully_duplicated_rows"] = int(df.duplicated().sum()) == 0
    results["no_duplicate_customer_id"] = int(df["customer_id"].duplicated().sum()) == 0

    ages = pd.to_numeric(df["age"], errors="coerce")
    results["no_missing_age"] = int(ages.isna().sum()) == 0
    results["ages_in_valid_range"] = bool(((ages >= AGE_MIN) & (ages <= AGE_MAX)).all())

    spending = pd.to_numeric(df["total_spending"], errors="coerce")
    results["no_missing_total_spending"] = int(spending.isna().sum()) == 0

    inconsistent = 0
    for _, row in df.iterrows():
        pc = pd.to_numeric(row["purchase_count"], errors="coerce")
        aov = pd.to_numeric(row["avg_order_value"], errors="coerce")
        ts = pd.to_numeric(row["total_spending"], errors="coerce")
        if pd.notna(pc) and pd.notna(aov) and pd.notna(ts):
            expected = round(float(pc * aov), 2)
            if abs(float(ts) - expected) > SPENDING_TOLERANCE:
                inconsistent += 1
    results["spending_consistent"] = inconsistent == 0

    row_1007 = df[df["customer_id"] == 1007]
    if not row_1007.empty:
        signup = pd.to_datetime(row_1007.iloc[0]["signup_date"], errors="coerce")
        results["customer_1007_signup_date"] = signup.strftime("%Y-%m-%d") == "2025-09-09"
    else:
        results["customer_1007_signup_date"] = False

    row_1030 = df[df["customer_id"] == 1030]
    results["customer_1030_spending"] = (
        not row_1030.empty
        and round(float(row_1030.iloc[0]["total_spending"]), 2) == 4079.14
    )

    row_1040 = df[df["customer_id"] == 1040]
    results["customer_1040_spending"] = (
        not row_1040.empty
        and round(float(row_1040.iloc[0]["total_spending"]), 2) == 1280.44
    )

    results["audit_log_exactly_5_rows"] = len(audit_df) == 5
    expected_ids = [1014, 1010, 1020, 1030, 1040]
    results["audit_log_correct_order"] = audit_df["customer_id"].tolist() == expected_ids

    return results


def validate_type_formatting_section(type_fmt_df: pd.DataFrame) -> dict[str, bool]:
    """اعتبارسنجی بخش DATA TYPE AND EXCEL FORMATTING CHANGES."""
    results: dict[str, bool] = {}
    results["type_formatting_exactly_8_rows"] = len(type_fmt_df) == 8
    expected_columns = [
        "column_name",
        "change_category",
        "transformation_applied",
        "source_type",
        "final_type",
        "excel_number_format",
        "description",
    ]
    results["type_formatting_columns"] = list(type_fmt_df.columns) == expected_columns
    return results


def report_dataframe_dtypes(df: pd.DataFrame) -> pd.Series:
    """نمایش dtype ستون‌های کلیدی پس از پاکسازی."""
    cols = ["age", "signup_date", "purchase_count", "avg_order_value", "total_spending"]
    return df[cols].dtypes


def report_excel_number_formats(excel_path: Path) -> dict[str, str]:
    """خواندن number format واقعی ستون‌ها از شیت Cleaned_Data."""
    wb = load_workbook(excel_path, read_only=False, data_only=False)
    ws = wb["Cleaned_Data"]
    header_map = {cell.value: cell.column for cell in ws[1]}
    formats: dict[str, str] = {}
    for col_name in ("signup_date", "avg_order_value", "total_spending", "age", "purchase_count"):
        if col_name in header_map:
            col_idx = header_map[col_name]
            formats[col_name] = ws.cell(row=2, column=col_idx).number_format
    wb.close()
    return formats


def validate_excel_formats(excel_path: Path) -> dict[str, bool]:
    """اعتبارسنجی number format شیت Cleaned_Data."""
    formats = report_excel_number_formats(excel_path)
    results = {
        "excel_signup_date_format": formats.get("signup_date") == "YYYY-MM-DD",
        "excel_avg_order_value_format": formats.get("avg_order_value") == "#,##0.00",
        "excel_total_spending_format": formats.get("total_spending") == "#,##0.00",
        "excel_age_integer_format": formats.get("age") == "0",
        "excel_purchase_count_integer_format": formats.get("purchase_count") == "0",
    }
    wb = load_workbook(excel_path, read_only=False, data_only=True)
    ws = wb["Cleaned_Data"]
    header_map = {cell.value: cell.column for cell in ws[1]}
    signup_col = header_map.get("signup_date")
    if signup_col:
        sample = ws.cell(row=2, column=signup_col).value
        results["signup_date_is_datetime"] = isinstance(sample, (datetime, date))
    wb.close()
    return results


def main() -> None:
    """تابع اصلی اجرای پروژه پاکسازی داده."""
    global audit_records, summary_stats

    print("=" * 60)
    print("شروع پروژه پاکسازی داده مشتری")
    print("Customer Data Cleaning Project")
    print("=" * 60)

    execution_ts = _now_str()
    execution_date = pd.Timestamp(datetime.now().date())

    audit_records = []
    summary_stats = {
        "script_execution_timestamp": execution_ts,
        "removed_duplicate_rows": 0,
        "duplicate_customer_id_conflicts": 0,
        "missing_ages_filled": 0,
        "invalid_ages_corrected": 0,
        "invalid_future_dates_blanked": 0,
        "missing_total_spending_filled": 0,
        "inconsistent_total_spending_corrected": 0,
    }

    # ── 1. بارگذاری ──
    raw_df = load_and_validate_data(INPUT_FILE)
    input_row_count = len(raw_df)
    summary_stats["input_row_count"] = input_row_count

    # ── 2. پاکسازی مرحله‌ای ──
    df = clean_duplicates(raw_df)
    df = clean_text_columns(df)
    df = clean_age(df)
    df = clean_signup_date(df, execution_date)
    df = clean_numeric_columns(df)
    df = clean_total_spending(df)

    output_row_count = len(df)
    summary_stats["output_row_count"] = output_row_count

    # ── 3. گزارش ممیزی ──
    audit_df = create_audit_log()
    type_fmt_df = create_type_formatting_changes()
    export_audit_csv(audit_df, type_fmt_df, OUTPUT_CSV_REPORT)
    print(f"✓ گزارش CSV ممیزی ذخیره شد: {OUTPUT_CSV_REPORT}")

    # ── 4. جدول خلاصه ──
    summary_df = pd.DataFrame(
        [
            {"metric": "Input row count", "value": input_row_count},
            {"metric": "Output row count", "value": output_row_count},
            {"metric": "Removed duplicate rows", "value": summary_stats["removed_duplicate_rows"]},
            {
                "metric": "Duplicate customer_id conflicts",
                "value": summary_stats["duplicate_customer_id_conflicts"],
            },
            {"metric": "Missing ages filled", "value": summary_stats["missing_ages_filled"]},
            {"metric": "Invalid ages corrected", "value": summary_stats["invalid_ages_corrected"]},
            {
                "metric": "Invalid/future dates blanked",
                "value": summary_stats["invalid_future_dates_blanked"],
            },
            {
                "metric": "Missing total_spending filled",
                "value": summary_stats["missing_total_spending_filled"],
            },
            {
                "metric": "Inconsistent total_spending corrected",
                "value": summary_stats["inconsistent_total_spending_corrected"],
            },
            {"metric": "Script execution timestamp", "value": execution_ts},
        ]
    )

    # ── 5. کنترل کیفیت ──
    quality_df = create_quality_checks(df, execution_date)

    # ── 6. خروجی اکسل ──
    export_formatted_excel(df, audit_df, summary_df, quality_df, type_fmt_df, OUTPUT_EXCEL)

    excel_output = OUTPUT_EXCEL
    if not excel_output.exists():
        fallback = OUTPUT_EXCEL.with_name(f"{OUTPUT_EXCEL.stem}_new{OUTPUT_EXCEL.suffix}")
        if fallback.exists():
            excel_output = fallback

    # ── 7. اعتبارسنجی خروجی ──
    validation = validate_output(df, audit_df)
    validation.update(validate_type_formatting_section(type_fmt_df))
    if excel_output.exists():
        validation.update(validate_excel_formats(excel_output))

    print("\n" + "=" * 60)
    print("Pandas dtypes (cleaned data)")
    print("=" * 60)
    print(report_dataframe_dtypes(df).to_string())

    if excel_output.exists():
        print("\n" + "=" * 60)
        print("Excel number formats (Cleaned_Data)")
        print("=" * 60)
        for col, fmt in report_excel_number_formats(excel_output).items():
            print(f"  {col}: {fmt}")

    print("\n" + "=" * 60)
    print("نتایج اعتبارسنجی / Validation Results")
    print("=" * 60)
    all_passed = True
    for check, passed in validation.items():
        status = "PASS" if passed else "FAIL"
        if not passed:
            all_passed = False
        print(f"  [{status}] {check}")
    if not all_passed:
        raise RuntimeError("اعتبارسنجی خروجی ناموفق بود / Output validation failed")

    # ── 8. خلاصه نهایی در ترمینال ──
    print("\n" + "=" * 60)
    print("خلاصه نهایی / Final Summary")
    print("=" * 60)
    print(f"  ردیف ورودی:  {input_row_count}")
    print(f"  ردیف خروجی:  {output_row_count}")
    print(f"  ردیف تکراری حذف‌شده:  {summary_stats['removed_duplicate_rows']}")
    print(f"  age گم‌شده پر شده:  {summary_stats['missing_ages_filled']}")
    print(f"  age نامعتبر اصلاح‌شده:  {summary_stats['invalid_ages_corrected']}")
    print(f"  تاریخ نامعتبر/آینده:  {summary_stats['invalid_future_dates_blanked']}")
    print(f"  total_spending پر شده:  {summary_stats['missing_total_spending_filled']}")
    print(f"  total_spending ناسازگار:  {summary_stats['inconsistent_total_spending_corrected']}")
    print(f"  تعداد کل رکوردهای ممیزی (سطح ردیف):  {len(audit_df)}")
    print(f"  تعداد رکوردهای type/formatting:  {len(type_fmt_df)}")
    print("=" * 60)
    print("پروژه با موفقیت تکمیل شد ✓")


if __name__ == "__main__":
    main()
