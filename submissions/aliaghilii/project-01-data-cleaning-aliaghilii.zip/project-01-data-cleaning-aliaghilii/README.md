# Data Cleaning – E-commerce Customer Dataset
**Project 01 – StudyBuild**
**Author:** Ali Aghili

## 1. Introduction & an Important Note on Data Structure

The project brief expected an order-level dataset (with Order ID, Product, Quantity, Discount, Order Date). However, the actual dataset received is **customer-level** — each row represents one customer with aggregated purchase statistics (customer_id, first_name, gender, age, city, province, signup_date, membership_tier, purchase_count, avg_order_value, total_spending, last_purchase_days, payment_method, device, discount_used, returned_items, satisfaction_score).

This mismatch is documented as the first finding; cleaning was based on the actual data received, not the theoretical description in the brief.

**Important consequence:** Some of the analysis questions listed in the brief cannot be answered with this data structure:
- "Which products sold the most?" → **Not answerable** (no Product column exists)
- "What effect did discounts have on sales?" → Only answerable as Yes/No, not by discount amount

All other listed questions (top-spending customers, average order value, most-used payment method, top-revenue cities, time-based trends) are fully answerable with this data.

## 2. Tools & Libraries Used
- Python (Jupyter Notebook)
- pandas, numpy
- scipy.stats (for the Pearson correlation hypothesis test)

## 3. Methodology
Work was carried out in 4 phases:
1. **Audit**: fully identifying issues without changing any data
2. **Decision**: documenting a decision and rationale for each issue *before* making any fix
3. **Execution**: applying the fixes
4. **Validation**: re-running all audit checks on the cleaned data to confirm results

## 4. Issues Found and Changes Made

| # | Issue | Change Applied | Reason |
|---|---|---|---|
| 1 | `age`=145 (customer_id=1010) | Converted to NaN | Biologically impossible value; a "typo of 45" theory was considered but not provable |
| 2 | `age` missing (2 rows: 1010, 1020) | Imputed with median | Median is more robust to outliers than mean |
| 3 | `total_spending`=25000 (customer_id=1030) | Converted to NaN, then reconstructed via `avg_order_value × purchase_count` | Formula held exactly for the other 59 rows; reconstruction is more precise than statistical imputation |
| 4 | `total_spending` missing (customer_id=1040) | Reconstructed via the same formula | Same reasoning as above |
| 5 | Fully duplicated row (customer_id=1014, appeared twice) | One copy removed | Prevents double-counting in future aggregations/analysis |
| 6 | `signup_date` stored as string | Converted to `datetime64` | Enables time-based analysis (duration, filtering, extracting year/month) in later phases |
| 7 | `gender` inconsistent with `first_name` (e.g. Reza repeatedly labeled F) | Original `gender` column **kept unchanged** (flagged as unreliable); new column `gender_inferred` added, based on real-world knowledge of Persian names | A crosstab showed gender has no reliable relationship with name (likely generated randomly); overwriting the original would have destroyed the raw data |
| 8 | `returned_items` > `purchase_count` (5 remaining rows) | Left unchanged, documented as a known limitation | Plausible explanation: purchase_count may count orders while returned_items counts individual items (one order can contain multiple items); not provable without an items-per-order column |
| 9 | `purchase_count`=0 alongside non-zero `avg_order_value` and `returned_items`>0 (customer_id=1024) | `purchase_count` converted to NaN, imputed with median (17), then `total_spending` reconstructed via formula | A Pearson correlation test between avg_order_value and purchase_count (r=-0.305, p=0.019) showed a real but weak relationship — too weak for precise prediction, so median was used for consistency |

### Checks Performed That Found No Issues (documented for transparency)
- Consistency of `city` with `province` (verified against real Iranian geography; done manually since only 8 cities were present)
- Consistency of `signup_date` with `last_purchase_days` (no customer purchased before their signup date)
- Consistency of `purchase_count=0` with `total_spending=0`
- Typos or extra whitespace in text columns (first_name, city, province, gender, membership_tier, payment_method, device, discount_used)
- Statistical outliers (IQR method) across all numeric columns — only `total_spending` had 5 statistical outliers, which on inspection were determined to be genuine high-spending customers (both purchase_count and avg_order_value were high, and the formula held exactly), so they were left unchanged

## 5. How Missing Values Were Handled
Each missing value was assessed individually rather than treated with one blanket rule:
- `age`: filled with median (no better estimation method was available)
- `total_spending` and part of `purchase_count`: instead of statistical imputation, the existing mathematical relationship in the data (`avg_order_value × purchase_count = total_spending`) was used to reconstruct exact values — more accurate than a median guess

## 6. How Duplicates Were Checked
Three levels of checks were performed:
1. Full duplication across all columns (including customer_id)
2. Duplication in customer_id only (same ID, different data)
3. Duplication across all columns **except** customer_id (same customer, mismatched ID)

Only one case (type 1) was found and removed.

## 7. Data Type Changes
- `signup_date`: converted from `object` (string) to `datetime64`
- `age`, `purchase_count`: converted from `float64` to `int32` (after confirming no genuine decimal values existed)

## 8. Outliers and Invalid Values
Beyond the specific cases in the table above (age=145, total_spending=25000, the inconsistent purchase_count=0 case), a systematic statistical outlier check (IQR method) was run across all numeric columns. Only `total_spending` showed 5 statistical outliers, which were investigated and determined to be genuine (not errors).

## 9. Differences Between Final and Original Versions
- 61 rows → 60 rows (1 duplicate record removed)
- 17 columns → 18 columns (`gender_inferred` added)
- 2 missing values (age, total_spending) resolved
- 2 invalid values (age=145, total_spending=25000) corrected
- 1 complex inconsistency (purchase_count=0 with conflicting related fields) resolved
- Data type corrected for 3 columns (signup_date, age, purchase_count)
- Original `gender` column left unchanged but flagged as unreliable
- 5 rows with `returned_items > purchase_count` intentionally left unchanged (documented known limitation)

## Files
- `cleaned_dataset_aliaghilii.xlsx` — the cleaned dataset
- `data_cleaning_aliaghilii.ipynb` — full notebook covering Audit, Decision, Execution, and Validation phases