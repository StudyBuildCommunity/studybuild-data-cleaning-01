# Customer Data Cleaning

## Project Overview

This project demonstrates a complete data cleaning workflow for an e-commerce customer dataset using **Python**, **Pandas**, and **Jupyter Notebook**.

The notebook identifies common data quality issues, applies appropriate cleaning techniques, and produces a cleaned dataset ready for further analysis.

---

## Project Structure

```
project-01-data-cleaning/
│
├── data/
│   ├── First Dataset.xlsx
│   └── cleaned_dataset_nargessabbagh.xlsx
│
├── notebook/
│   └── data-cleaning-nargessabbagh.ipynb
│
├── report/
│   └── data cleaning first project documentation.pdf
│
└── README.md
```

---

## Dataset

The dataset contains customer information, including:

- Customer ID
- First Name
- Gender
- Age
- City
- Province
- Signup Date
- Membership Tier
- Purchase Count
- Average Order Value
- Total Spending
- Last Purchase Days
- Payment Method
- Device
- Discount Usage
- Returned Items
- Satisfaction Score

---

## Data Cleaning Tasks

The notebook performs the following operations:

- Missing value handling
- Duplicate record removal
- Business rule validation
- Gender consistency correction
- Data type conversion
- Outlier detection and treatment
- Final data validation

---

## Technologies Used

- Python
- Pandas
- NumPy
- Jupyter Notebook
- Visual Studio Code

---

## How to Run

1. Open the project in Visual Studio Code.
2. Open `notebook/data-cleaning-nargessabbagh.ipynb`.
3. Install the required libraries if needed.
4. Run all notebook cells in order.

---

## Output

The project includes:

- Cleaned dataset (`cleaned_dataset_nargessabbagh.xlsx`)
- Jupyter Notebook containing the complete cleaning workflow
- Project documentation (`data cleaning first project documentation.pdf`)

---

## Notes

This repository contains my individual implementation and documentation of the group's data cleaning project.

---

## Author

**Narges Sabbagh**
Bachelor of Computer Engineering (Software)

